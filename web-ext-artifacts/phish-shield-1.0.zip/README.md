# Mozilla-extension-phish-shield
This is the mozilla extension code for our project phish-shield.
This extension detects Phishing/Malware URL using Machine Learning.
We have API deployed on heroku server. Extension get results form the API.
Link to API: https://phishshield.herokuapp.com/

<h1>Building the Extension</h1>
There is no seperate dependency/process to build this extension. <br>
It's just simple HTML, CSS and JS code.<br>
All other dependencies are handled on server side.
Just load the extension and you will be ready to go.
Thank You.
